import { Component ,OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';






@Component({
  selector: 'app-add-rooms',
  templateUrl: './add-rooms.component.html',
  styleUrls: ['./add-rooms.component.scss']
})
export class AddRoomsComponent {

  addRoomsForm:FormGroup;
  submitted:boolean=false;
  message:string=undefined;
  errors:string[]=[];
  messages:string[]=[];
  bsDatePicker:string[]=[];
  bsConfig:boolean=true;
  minDate: any;
  

  constructor(private formBuilder:FormBuilder,private router:Router,){}
  ngOnInit():void{

    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate());

    this.addRoomsForm=this.formBuilder.group({
      roomnumber:['',[Validators.required]],
      roomtype:['',[Validators.required]],
      // type_room:['',[Validators.required]],
      food:['',[Validators.required]],
      bed_count:['',[Validators.required]],
      charges:['',[Validators.required]],
      rent:['',[Validators.required]],
      phonenumber:['',Validators.compose([Validators.required,Validators.pattern(
        '(([+][(]?[0-9]{1,3}[)]?)|([(]?[0-9]{4}[)]?))\s*[)]?[-\s\.]?[(]?[0-9]{1,3}[)]?([-\s\.]?[0-9]{3})([-\s\.]?[0-9]{3,4})'
          )])],
      file:['',[Validators.required]],
      text:['',[Validators.required]]

    });
  }
get f(){
  return this.addRoomsForm.controls;
}
 saveAddRooms(){
  this.submitted=true;
  this.errors=[];
  this.messages=[];

  if(!this.addRoomsForm.valid){
    return;
  }
  (error:any) => {
    console.log(error);
    this.submitted=false;
    this.errors=[error.error.Message];
    
  }
 }
 

  }
  

