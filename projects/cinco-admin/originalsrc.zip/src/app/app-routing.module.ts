import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { HeaderComponent } from './header/header.component';
import { SideBarComponent } from './side-bar/side-bar.component';

import { AddCustomerComponent } from './add-customer/add-customer.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';
import { AllCustomersComponent } from './all-customers/all-customers.component';
import { CustomersComponent } from './customers/customers.component';
import { RoomsComponent } from './rooms/rooms.component';
import { AllRoomsComponent } from './all-rooms/all-rooms.component';
import { AddRoomsComponent } from './add-rooms/add-rooms.component';
import { EditRoomsComponent } from './edit-rooms/edit-rooms.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentInvoicesComponent } from './payment-invoices/payment-invoices.component';
import { ReportsComponent } from './reports/reports.component';
import { SettingsComponent } from './settings/settings.component';
import { MastersComponent } from './masters/masters.component';
import { RoomsTypeComponent } from './rooms-type/rooms-type.component';
import { FoodTypeComponent } from './food-type/food-type.component';
import { LocationComponent } from './location/location.component';
import { CalendarComponent } from './calendar/calendar.component';
import { CreateInvoiceComponent } from './create-invoice/create-invoice.component';
import { CompanySettingsComponent } from './company-settings/company-settings.component';
import { RolesPermissionsComponent } from './roles-permissions/roles-permissions.component';
import { EmailSettingsComponent } from './email-settings/email-settings.component';
import { InvoiceSettingsComponent } from './invoice-settings/invoice-settings.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { LoginComponent } from './login/login.component';

import { ProfileComponent } from './profile/profile.component';
import { PaymentReceiptComponent } from './payment-receipt/payment-receipt.component';

import { EditTestimonialsComponent } from './edit-testimonials/edit-testimonials.component';
import { ListTestimonialComponent } from './list-testimonial/list-testimonial.component';
import { AddTestimonialsComponent } from './add-testimonials/add-testimonials.component';
import { InventoryComponent } from './inventory/inventory.component';
import { BranchesComponent } from './branches/branches.component';
import { AddBranchComponent } from './add-branch/add-branch.component';
import { EmployeeComponent } from './employee/employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmpLoginComponent } from './emp-login/emp-login.component';


const routes: Routes = [
  {
    path:'',
    component:DashBoardComponent,

    },
  {
    path:'dash-board',
    component:DashBoardComponent,

    },
    {
      path:'header',
      component:HeaderComponent,
    },
    {
      path:'side-bar',
      component:SideBarComponent,
    },
    {
      path:'add-customer',
      component:AddCustomerComponent,
    },
    {
      path:'edit-customer',
      component:EditCustomerComponent
    },
    {
      path:'all-customers',
      component:AllCustomersComponent
    },
    {
      path:'customers',
      component:CustomersComponent
    },
    {
      path:'rooms',
      component:RoomsComponent
    },
    {
      path:'all-rooms',
      component:AllRoomsComponent
    },
    {
      path:'add-rooms',
      component:AddRoomsComponent
    },
    {
      path:'edit-rooms',
      component:EditRoomsComponent
    },
    
    {
      path:'payments',
      component:PaymentsComponent
    },
    {
      path:'payment-invoices',
      component:PaymentInvoicesComponent
    },
    
    {
      path:'reports',
      component:ReportsComponent
    },
    {
      path:'settings',
      component:SettingsComponent
    },
    {
      path:'masters',
      component:MastersComponent
    },
    {
      path:'rooms-type',
      component:RoomsTypeComponent
    },
    {
      path:'food-type',
      component:FoodTypeComponent
    },
    {
      path:'location',
      component:LocationComponent
    },
    {
      path:'calendar',
      component:CalendarComponent
    },
    {
      path:'create-invoice',
      component:CreateInvoiceComponent
    },
    {
      path:'company-settings',
      component:CompanySettingsComponent
        },
        {
          path:'roles-permissions',
          component:RolesPermissionsComponent
        },  
        {
          path:'email-settings',
          component:EmailSettingsComponent
        },
        {
          path:'invoice-settings',
          component:InvoiceSettingsComponent
        },
        {
          path:'notifications',
          component:NotificationsComponent
        },
        {
          path:'change-password',
          component:ChangePasswordComponent
        },
        {
          path:'add-role',
          component:AddRoleComponent
        },
        {
          path:'login',
          component:LoginComponent
        },
    
        
        {
          path:'profile',
          component:ProfileComponent
        },
        {
          path:'payment-receipt',
          component:PaymentReceiptComponent
        },
      
        {
          path:'edit-testimonials',
          component:EditTestimonialsComponent
        },
        {
          path:'list-testimonials',
          component:ListTestimonialComponent
        },
        {
          path:'add-testimonials',
          component:AddTestimonialsComponent
        },
        {
          path:'inventory',
          component:InventoryComponent
        },
        {
          path:'branches',
          component:BranchesComponent
        },
        {
          path:'add-branch',
          component:AddBranchComponent
        },
        {
          path:'employee',
          component:EmployeeComponent
        },
        {
         path:'add-employee',
         component:AddEmployeeComponent
        },
        {
         path:'emp-login',
         component:EmpLoginComponent
        }   
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ scrollPositionRestoration: "enabled" })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
