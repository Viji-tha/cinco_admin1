export interface User {
    id: string,
    email: any;
    password: any;
    platformUserId: string,
    
  }
  