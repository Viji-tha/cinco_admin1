import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';


interface TableRow {
  branch_code: string;
  name: string;
  location: string;
  // created_date:string;
  // updated_date:string;

  room_type:string;
  sharing:string;
  price:string;
  total_rooms:string;
  // created_person_id:string;
  // updated_person_id:string;
   
}


@Component({
  selector: 'app-branches',
  templateUrl: './branches.component.html',
  styleUrls: ['./branches.component.scss']
})
export class BranchesComponent {





tableData: TableRow[] = [
    
  {
    branch_code: 'B001',
  name: 'TheCincoGrand',
  location: 'Banjarahills',
  // created_date:'10-07-2023',
  // updated_date:'10-10-2023',

  room_type:'Deluxe & Standard',
  sharing:'Single & Double',
  price:'2200',
  total_rooms:'125',
  // created_person_id:'B10101',
  // updated_person_id:'B10110',

  },
  {
    branch_code: 'B002',
  name: 'TheCincoGrand',
  location: 'Begumpet',
  // created_date:'10-07-2023',
  // updated_date:'10-10-2023',

  room_type:'Standard',
  sharing:'Single & Double',
  price:'2200',
  total_rooms:'125',
  // created_person_id:'B10101',
  // updated_person_id:'B10110'
  },
  {
    branch_code: 'B003',
  name: 'TheCincoGrand',
  location: 'ESI',
  // created_date:'10-07-2023',
  // updated_date:'10-10-2023',

  room_type:'Standard',
  sharing:'Single & Double',
  price:'2200',
  total_rooms:'125',
  // created_person_id:'B10101',
  // updated_person_id:'B10110'
  },
  ];

filteredData: TableRow[] = [...this.tableData];
currentPage = 1;
itemsPerPage = 5;
sortKey: keyof TableRow | null = null;
sortDirection: string = 'asc';

filterTable(filterValue: string) {
  // Perform filtering based on the filterValue
  this.filteredData = this.tableData.filter((row) => {
    return (
      row.branch_code.toLowerCase().includes(filterValue.toLowerCase())
    );
  });
  this.currentPage = 1; // Reset pagination to the first page
}

sortTable(key: keyof TableRow) {
  if (this.sortKey === key) {
    // If the same key is clicked, reverse the sort direction
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    this.sortKey = key;
    this.sortDirection = 'asc';
  }

  // Perform sorting based on the sortKey and sortDirection
  this.filteredData.sort((a, b) => {
    const valA = a[this.sortKey!];
    const valB = b[this.sortKey!];
    if (valA < valB) {
      return this.sortDirection === 'asc' ? -1 : 1;
    } else if (valA > valB) {
      return this.sortDirection === 'asc' ? 1 : -1;
    } else {
      return 0;
    }
  });
}

getPaginatedData() {
  const startIndex = (this.currentPage - 1) * this.itemsPerPage;
  const endIndex = startIndex + this.itemsPerPage;
  return this.filteredData.slice(startIndex, endIndex);
}

setPage(page: number) {
  this.currentPage = page;
}

getTotalPages(): number {
  return Math.ceil(this.filteredData.length / this.itemsPerPage);
}


}
