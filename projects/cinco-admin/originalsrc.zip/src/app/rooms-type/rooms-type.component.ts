import { Component } from '@angular/core';

@Component({
  selector: 'app-rooms-type',
  templateUrl: './rooms-type.component.html',
  styleUrls: ['./rooms-type.component.scss']
})
export class RoomsTypeComponent {


 

}
