import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomsTypeComponent } from './rooms-type.component';

describe('RoomsTypeComponent', () => {
  let component: RoomsTypeComponent;
  let fixture: ComponentFixture<RoomsTypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RoomsTypeComponent]
    });
    fixture = TestBed.createComponent(RoomsTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
