// Angular Modules 
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/internal/Observable';
import { ApiResponse } from './models/api-response';


@Injectable()
export class ApiService {
  saveAddBranch(url: string, body: { name: any; logo: any; location: any; room_info: { type: any; sharing: any; price: any; currency: string; available_rooms: string; }[]; total_rooms: string; is_active: boolean; is_archive: boolean; created_by: string; }) {
    throw new Error('Method not implemented.');
  }
 
    private DOMAIN_URL ="http://192.168.0.156:9091/api/v1/";
    constructor(
        // Angular Modules 
        private http: HttpClient
    ) { }
    public get(url: string): Observable<ApiResponse<any>> {
        return this.http.get<ApiResponse<any>>(this.DOMAIN_URL+url);
    }
    public getWithToken(url: string): Observable<ApiResponse<any>> {

        return this.http.get<ApiResponse<any>>(this.DOMAIN_URL+url, {headers:  new HttpHeaders({ 'No-Auth': 'false' })});
    }
    public post(url: any,data: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'false' });
        return this.http.post(this.DOMAIN_URL+url, data);
    }
    public put(url: string, data: any, options?: any) {
        return this.http.put(url, data, options);
    }
    public delete(url: string, options?: any) {
        return this.http.delete(url, options);
    }

    login(url: any,email: any, password: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
        return this.http.post<any>(this.DOMAIN_URL+url, {
          mobileNumber: email,
          password: password
        }, { headers: reqHeader })
      }
      forgot(url: any,email: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
        return this.http.post<any>(this.DOMAIN_URL+url, {
          mobileNumber: email,
      
        }, { headers: reqHeader })
      }
      register(url: any,body: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
        return this.http.post<any>(this.DOMAIN_URL+url, body, 
            { headers: reqHeader })
      }
      // shopcart(url: any,body: any) {
      //   var reqHeader = new HttpHeaders({ 'No-Auth': 'False' });
      //   return this.http.post<any>(this.DOMAIN_URL+url, body, 
      //       { headers: reqHeader })
      // }
      requestquote(url: any,body: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'False' });
        return this.http.post<any>(this.DOMAIN_URL+url, body, 
            { headers: reqHeader })
      }
      // createOrder(url: any,body: any) {
      //   var reqHeader = new HttpHeaders({ 'No-Auth': 'False' });
      //   return this.http.post<any>(this.DOMAIN_URL+url, body, 
      //       { headers: reqHeader })
      // }
      CustomerAddress(url: any,body: any) {
        var reqHeader = new HttpHeaders({ 'No-Auth': 'False' });
        return this.http.post<any>(this.DOMAIN_URL+url, body, 
            { headers: reqHeader })
      }
} 