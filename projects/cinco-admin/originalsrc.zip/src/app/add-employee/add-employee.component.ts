import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent {

  addEmployeeForm:FormGroup;
  submitted:boolean=false;
  message:string=undefined;
  errors:string[]=[];
  messages:string[]=[];

  bsDatePicker:string[]=[];
  bsTimePicker:string[]=[];
  bsRangeValue: Date[];
  maxDate = new Date();
  minDate = new Date();
  bsConfig:boolean=true;
  currentTime: string;
 




  constructor(private formBuilder:FormBuilder,private router:Router,){
    //  -------automatic time start--------

   


    // ------------automatic time ends---------
   
  
}
  ngOnInit():void{
    
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate());


    this.addEmployeeForm=this.formBuilder.group({
      
      emp_name:['',[Validators.required]],
      gender:['',[Validators.required]],
      emp_email:['',[Validators.required, Validators.pattern(/^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/)]],
      password:['',[Validators.required]],
      emp_id:['',[Validators.required]],
      date:['',[Validators.required]],
      // dob:['',[Validators.required]],
      contact_no:['',Validators.compose([Validators.required,Validators.pattern(
        '(([+][(]?[0-9]{1,3}[)]?)|([(]?[0-9]{4}[)]?))\s*[)]?[-\s\.]?[(]?[0-9]{1,3}[)]?([-\s\.]?[0-9]{3})([-\s\.]?[0-9]{3,4})'
          )])],
      branh_code:['',[Validators.required]],
      add1:['',[Validators.required]],
      add2:['',[Validators.required]],
      city:['',[Validators.required]],
      state:['',[Validators.required]],
      Zip_code:['',[Validators.required]],
      country:['',[Validators.required]],
      file:['',[Validators.required]],
      
    });
  }
get f(){
  return this.addEmployeeForm.controls;
}
 saveAddEmployee(){
  this.submitted=true;
  this.errors=[];
  this.messages=[];

  if(!this.addEmployeeForm.valid){
    return;
  }
  // (error:any) => {
  //   console.log(error);
  //   this.submitted=false;
  //   this.errors=[error.error.Message];
    
  // }

  const selectedDate: Date = this.addEmployeeForm.value.date;
  const currentDate: Date = new Date();

   if(selectedDate<currentDate){
     console.log('Selected date is not valid.Please choose a date in the future.');

  }



else{
(error:any) => {
  console.log(error);
  this.submitted=false;
  this.errors=[error.error.Message];
  
}
}
 }}
