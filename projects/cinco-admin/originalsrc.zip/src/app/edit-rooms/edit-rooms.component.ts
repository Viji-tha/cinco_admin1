import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-rooms',
  templateUrl: './edit-rooms.component.html',
  styleUrls: ['./edit-rooms.component.scss']
})
export class EditRoomsComponent {

  editRoomsForm:FormGroup;
  submitted:boolean=false;
  message:string=undefined;
  errors:string[]=[];
  messages:string[]=[];

  bsDatePicker:string[]=[];
  bsConfig:boolean=true;
  

  constructor(private formBuilder:FormBuilder,private router:Router,){}
  ngOnInit():void{
    this.editRoomsForm=this.formBuilder.group({
      rnumber:['',[Validators.required]],
      rtype:['',[Validators.required]],
      type_room:['',[Validators.required]],
      food:['',[Validators.required]],
      bedcount:['',[Validators.required]],
      charges:['',[Validators.required]],
      rent:['',[Validators.required]],
      phonenumber:['',Validators.compose([Validators.required,Validators.pattern(
        '(([+][(]?[0-9]{1,3}[)]?)|([(]?[0-9]{4}[)]?))\s*[)]?[-\s\.]?[(]?[0-9]{1,3}[)]?([-\s\.]?[0-9]{3})([-\s\.]?[0-9]{3,4})'
          )])],
      file:['',[Validators.required]],
      text:['',[Validators.required]]

    });
  }
get f(){
  return this.editRoomsForm.controls;
}
 saveEditRooms(){
  this.submitted=true;
  this.errors=[];
  this.messages=[];

  if(!this.editRoomsForm.valid){
    return;
  }
  (error:any) => {
    console.log(error);
    this.submitted=false;
    this.errors=[error.error.Message];
    
  }
 }

}
