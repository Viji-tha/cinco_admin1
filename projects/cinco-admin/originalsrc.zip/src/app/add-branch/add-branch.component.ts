import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'app-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.scss']
})
export class AddBranchComponent implements OnInit {

  rooms: any[] = [];
  addBranchForm:FormGroup;
  submitted:boolean=false;
  message:string=undefined;
  // isSelected:any;
  errors:string[]=[];
  messages:string[]=[];

 

  time: Date = new Date();  
  constructor(private formBuilder:FormBuilder,private router:Router){
}
  ngOnInit():void{

        this.addBranchForm=this.formBuilder.group({
      branch_code:['',[Validators.required]],
      name:['',[Validators.required]],
      location:['',Validators.required] , 
      total_rooms:['',[Validators.required,Validators.pattern('[0-9]')]],
      rooms: this.formBuilder.array([this.createRoom()]),
      
      
    });
  }
get f(){
  return this.addBranchForm.controls;
}

createRoom(): FormGroup {
  return this.formBuilder.group({
    room_type: ['', Validators.required],
    sharing: ['', Validators.required],
    price: ['', Validators.required],
  });
}
get roomsFormArray(): FormArray {
  return this.addBranchForm.get('rooms') as FormArray;
}
addRoom(): void {
  this.roomsFormArray.push(this.createRoom());
}
removeRoom(index: number): void {
  this.roomsFormArray.removeAt(index);
}
 saveAddBranch(){
  this.submitted=true;
  this.errors=[];
  this.messages=[];

  if(!this.addBranchForm.valid){
    return;
  }
  (error:any) => {
    console.log(error);
    this.submitted=false;
    this.errors=[error.error.Message];
    
  }
 }

 }