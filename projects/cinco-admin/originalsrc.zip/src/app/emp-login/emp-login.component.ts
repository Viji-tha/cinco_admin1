import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../environments/environment';
import { ApiService } from '../api.client';
import { UtilsService } from '../utils/utilities-service';

@Component({
  selector: 'app-emp-login',
  templateUrl: './emp-login.component.html',
  styleUrls: ['./emp-login.component.scss']
})
export class EmpLoginComponent {
// ----------previous Data-----------
empLoginForm: FormGroup ;
submitted:boolean=false;
data:any;
// signUpForm: FormGroup ;
api_url = environment.API_URL;
message: string | undefined;
errors: string[] = [];
messages: string[] = [];
public is_form_view : boolean = false;

   

  constructor(private formBuilder:FormBuilder, private router: Router,private api: ApiService, private util: UtilsService,  public toast: ToastrService){}
  ngOnInit():void{
    this.empLoginForm=this.formBuilder.group({
      password:['',[Validators.required]],
      // email:['', Validators.required, Validators.pattern(/^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/)],
      name:['',[Validators.required]],
      id:['',[Validators.required]],
      remember_me:['']

    });
  }
  get f() {
    return this.empLoginForm.controls;
  }
  // get f1() {
  //   return this.signUpForm.controls;
  // }
  list(status){
    this.is_form_view = status;
   }
  saveNewMember() {
    this.submitted = true;
    this.errors = [];
    this.messages = [];
  
  
    if (!this.empLoginForm.valid) {
      return;
    }
    
      
      
    const url="Account/admin/login";
    var body ={
      "mobileNumber": this.empLoginForm.get("email"),
      "password": this.empLoginForm.get("password"),
      "fcm_Token": "string"
    }
    this.api.login(url,this.empLoginForm?.get("email")?.value, this.empLoginForm?.get("password")?.value).subscribe((res: any) => {
      
      localStorage.setItem('access_token', this.util.encrypt_Text(res.data?.jwToken) || "")
     
      localStorage.setItem('user_id', this.util.encrypt_Text(res.data.id) || "");
      localStorage.setItem('currentUser', this.util.encrypt_Text(JSON.stringify(res.data)) || "");
      
      
      this.router.navigate(['/dash-board']);
      
      
      this.submitted = false;     
    },
      (error: any) => {
  
        console.log(error);
        // this.loaded=false;        
        // this.SpinnerService.hide();
        
        // console.log("====================")
        this.submitted = false;
      //  this.errors = [error.error.Message];
        this.toast.error(this.errors[0],"Validation Failed");
         //this.loaded=false;
      }
      
    );
    
  
  
  }
}
