export const environment = {
    production: false,
    API_URL: 'https://localhost:4200/',
  };
  