export const environment = {
    production: false,
    API_URL: 'https://localhost:44389/',
  };